const btnHumburger = document.getElementById('btn-hum')
const btnMenus = document.getElementById('btn-menus')
const btnClose = document.getElementById('btn-close')
const list = document.querySelector('.list-menu')
const bodyHtml = document.getElementById('body-html')

document.addEventListener('click', (e) => {
    
    if (list.classList.contains('hidden')&&btnHumburger.contains(e.target)) {
        list.classList.replace('hidden','flex')
        btnMenus.src="/public/src/images/icons/close.svg"
        e.preventDefault()    
    } else {
        list.classList.replace('flex','hidden')
        btnMenus.src='/public/src/images/icons/menu.svg'
        console.log(btnMenus.contains(e.currentTarget))
        return
    }

})
